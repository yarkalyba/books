function appendText(title, photo, description, likes, dislikes) {
    var table = document.getElementById("myTable");
    var row = table.insertRow(-1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    cell1.innerHTML = "<h1>"+ title + "</h1>";
    cell2.innerHTML =  "<td><img src='"+ photo + "height='200' width='150'/></td>";
    cell3.innerHTML = "<td><p>" +description +"</p></td>";
    cell4.innerHTML = "<td><p>" +likes + "</p></td>";
        cell5.innerHTML = "<td><p>" + dislikes  + "</p></td>";
}